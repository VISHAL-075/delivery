import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store/store';
import { Header } from './components/layout/Header';
import { LoginForm } from './components/auth/LoginForm';
import { CreateOrder } from './components/order/CreateOrder';

function App() {
  return (
    <Provider store={store}>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <Routes>
              <Route path="/" element={
                <div className="text-center">
                  <h1 className="text-4xl font-bold text-gray-900 mb-8">
                    Fast, Reliable Delivery at Your Fingertips
                  </h1>
                  <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
                    Connect with trusted drivers and get your packages delivered safely and on time.
                  </p>
                  <CreateOrder />
                </div>
              } />
              <Route path="/login" element={<LoginForm />} />
            </Routes>
          </main>
        </div>
      </Router>
    </Provider>
  );
}

export default App;