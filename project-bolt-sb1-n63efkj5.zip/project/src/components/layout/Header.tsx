import React from 'react';
import { Package } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Package className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">DeliveryHub</span>
            </Link>
          </div>
          <nav className="flex space-x-8">
            <Link to="/track" className="text-gray-700 hover:text-indigo-600">
              Track Order
            </Link>
            <Link to="/become-driver" className="text-gray-700 hover:text-indigo-600">
              Become a Driver
            </Link>
            <Link to="/login" className="text-gray-700 hover:text-indigo-600">
              Login
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}