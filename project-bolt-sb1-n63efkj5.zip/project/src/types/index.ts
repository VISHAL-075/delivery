export interface User {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'driver' | 'admin';
  createdAt: Date;
}

export interface Order {
  id: string;
  customerId: string;
  driverId?: string;
  status: 'pending' | 'accepted' | 'pickup' | 'delivering' | 'delivered';
  pickupLocation: Location;
  deliveryLocation: Location;
  price: number;
  createdAt: Date;
  estimatedDeliveryTime?: Date;
}

export interface Location {
  latitude: number;
  longitude: number;
  address: string;
}

export interface Rating {
  id: string;
  orderId: string;
  rating: number;
  comment?: string;
  createdAt: Date;
}